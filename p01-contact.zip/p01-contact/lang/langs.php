<?php 
/**
 * p01-contact translations list
 * @author Nicolas Liautaud
 * @package p01-contact
 */
$p01contact_langs = array(
'de' => 'Deutsch',
'en' => 'English',
'es' => '~Español',
'fr' => 'Français',
'it' => '~Italiano',
'nl' => '~Nederlands',
'ru' => '~русский язык',
'sv' => '~Svenska'
);?>
